def remove_list_blank(list_object):
    """ 删除列表中的空白元素 """
    return [i for i in list_object if i != '']

